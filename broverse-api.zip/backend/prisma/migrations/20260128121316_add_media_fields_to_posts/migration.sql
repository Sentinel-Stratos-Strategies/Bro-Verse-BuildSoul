-- AlterTable
ALTER TABLE "Post" ADD COLUMN     "mediaBlobName" TEXT,
ADD COLUMN     "mediaType" TEXT;
